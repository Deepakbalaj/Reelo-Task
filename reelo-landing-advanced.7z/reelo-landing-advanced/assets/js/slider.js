
// assets/js/slider.js - lightweight testimonial carousel (no dependency)
class SimpleSlider {
  constructor(root, opts={}){
    this.root = root; this.index = 0;
    this.slides = root.querySelectorAll('.slide');
    this.total = this.slides.length;
    this.next = root.querySelector('.next');
    this.prev = root.querySelector('.prev');
    this.setup();
    if(opts.autoplay) this.autoplay(opts.delay||3000);
  }
  setup(){
    this.show(0);
    if(this.next) this.next.addEventListener('click', ()=> this.show(this.index+1));
    if(this.prev) this.prev.addEventListener('click', ()=> this.show(this.index-1));
  }
  show(i){
    this.index = (i + this.total) % this.total;
    this.slides.forEach((s,idx)=> s.style.display = idx===this.index ? 'block' : 'none');
  }
  autoplay(delay=3000){
    setInterval(()=> this.show(this.index+1), delay);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll('.card');
  cards.forEach((card, i) => {
    card.style.transitionDelay = `${i * 0.2}s`;
    card.classList.add('in');
  });
});
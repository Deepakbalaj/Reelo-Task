
// assets/js/main.js - page initializer
document.addEventListener('DOMContentLoaded', function(){
  // simple scroll reveal logic
  const reveal = (selector, offset=120) => {
    const els = document.querySelectorAll(selector);
    const onScroll = () => {
      els.forEach(el => {
        const rect = el.getBoundingClientRect();
        if(rect.top <= (window.innerHeight - offset)){
          el.classList.add('in');
        }
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll);
  };
  reveal('.fade-up', 120);
  reveal('.scale-in', 120);

  // header shrink on scroll
  const header = document.querySelector('.header-inner');
  window.addEventListener('scroll', ()=>{
    if(window.scrollY > 20) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  });

  // simple smooth anchor links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      e.preventDefault();
      const t = document.querySelector(this.getAttribute('href'));
      if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
    });
  });
});
